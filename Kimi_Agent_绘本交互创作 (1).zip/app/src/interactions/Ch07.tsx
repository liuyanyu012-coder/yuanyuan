import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SceneImage, GoldButton, CountUp } from "../components/bits";
import { IMG } from "../data/story";

const STEPS = [
  { id: "leach", name: "浸出", desc: "黑色粉末落入酸液，金属离子像冰块融进温水。", color: "#5d6f7d", rate: null },
  { id: "co", name: "钴", desc: "溶液变成深蓝色，钴离子汇聚沉淀。", color: "#3a5f9e", rate: 99.2 },
  { id: "ni", name: "镍", desc: "青绿色的溶液里，镍被“请”了出来。", color: "#3fa08a", rate: 99.5 },
  { id: "mn", name: "锰", desc: "淡紫色的锰，安静地沉入槽底。", color: "#8a7ab8", rate: 99.1 },
  { id: "li", name: "锂", desc: "最后，清澈的溶液中，锂离子像轻盈的精灵。", color: "#c8ccd4", rate: 96.3 },
];

export default function Ch07() {
  const [step, setStep] = useState(0);
  const current = STEPS[step];
  const finished = step === STEPS.length - 1;

  return (
    <div className="relative h-full w-full">
      <SceneImage
        src={step === 0 ? IMG("scene11") : IMG("scene12")}
        alt={step === 0 ? "湿法冶金车间，不锈钢反应罐安静运转" : "烧杯中深浅不一的金属溶液"}
        className="absolute inset-0"
      />

      {/* step status */}
      <AnimatePresence mode="wait">
        <motion.div
          key={current.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="absolute left-1/2 top-[8%] z-20 w-[88%] max-w-md -translate-x-1/2 bg-marine/90 p-4 text-center shadow-lg"
          style={{ borderTop: `3px solid ${current.color}` }}
        >
          <p className="font-display text-xl" style={{ color: step === 0 ? "#f4ecd8" : current.color === "#c8ccd4" ? "#e8ecf2" : current.color }}>
            {current.name}
            {current.rate !== null && (
              <span className="ml-3 text-2xl text-gold">
                <CountUp to={current.rate} decimals={1} start suffix="%" />
              </span>
            )}
          </p>
          <p className="mt-1 text-sm leading-relaxed text-[#f4ecd8]/90">{current.desc}</p>
        </motion.div>
      </AnimatePresence>

      {/* step controls */}
      <div className="absolute bottom-[5%] left-1/2 z-20 flex -translate-x-1/2 flex-col items-center gap-3">
        <div className="flex items-center gap-2">
          {STEPS.map((s, i) => (
            <button
              key={s.id}
              type="button"
              aria-label={`步骤：${s.name}`}
              onClick={() => setStep(i)}
              className="h-3 w-3 cursor-pointer rounded-full border border-white/80 transition-all"
              style={{
                background: i <= step ? s.color : "rgba(255,255,255,.35)",
                transform: i === step ? "scale(1.4)" : "scale(1)",
              }}
            />
          ))}
        </div>
        {!finished ? (
          <GoldButton onClick={() => setStep((s) => Math.min(s + 1, STEPS.length - 1))}>
            {step === 0 ? "开始浸出" : `分离下一种金属 · ${STEPS[step + 1].name}`}
          </GoldButton>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-leaf px-6 py-3 text-center shadow-xl"
          >
            <p className="font-display text-lg text-white">电池级原料 · 纯度 99.9%</p>
            <p className="text-xs tracking-[0.25em] text-white/80">回收率全部达标</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
