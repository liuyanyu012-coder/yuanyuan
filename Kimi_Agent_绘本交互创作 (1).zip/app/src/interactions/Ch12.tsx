import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SceneImage, GoldButton } from "../components/bits";
import { IMG } from "../data/story";

export default function Ch12({ onRestart }: { onRestart: () => void }) {
  const [lit, setLit] = useState(false);
  const [line, setLine] = useState(0);

  const begin = () => {
    setLit(true);
    window.setTimeout(() => setLine(1), 1200);
    window.setTimeout(() => setLine(2), 3400);
    window.setTimeout(() => setLine(3), 5800);
  };

  return (
    <div className="relative h-full w-full">
      <SceneImage
        src={lit ? IMG("scene22") : IMG("scene21")}
        alt={lit ? "城市夜景，万家灯火，电池安静工作" : "清晨，新能源汽车驶过跨海大桥"}
        className="absolute inset-0"
      />

      {!lit && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="absolute bottom-[8%] left-1/2 z-20 -translate-x-1/2"
        >
          <GoldButton onClick={begin}>点亮万家灯火</GoldButton>
        </motion.div>
      )}

      {/* closing lines */}
      <AnimatePresence>
        {line >= 1 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
            className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-marine/55 px-6 text-center backdrop-blur-[2px]"
          >
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9 }}
              className="font-narr text-xl leading-relaxed text-[#f4ecd8] md:text-2xl"
            >
              淘汰的电池，从来不是垃圾。
            </motion.p>
            {line >= 2 && (
              <motion.p
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.9 }}
                className="font-narr mt-4 text-xl leading-relaxed text-[#f4ecd8] md:text-2xl"
              >
                它只是换了一种方式，等待被数字科技唤醒，再次出发。
              </motion.p>
            )}
            {line >= 3 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
                className="mt-10 flex flex-col items-center gap-6"
              >
                <h2 className="font-display text-4xl tracking-[0.12em] text-gold md:text-5xl">
                  终点是新的起点
                </h2>
                <p className="text-sm tracking-[0.4em] text-[#f4ecd8]/70">城市矿山计划</p>
                <GoldButton onClick={onRestart}>回到封面 · 再读一遍</GoldButton>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
