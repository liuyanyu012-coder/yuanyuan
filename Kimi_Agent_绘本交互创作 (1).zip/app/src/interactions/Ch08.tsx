import { useState } from "react";
import { motion } from "framer-motion";
import { SceneImage, GoldButton, CountUp } from "../components/bits";
import { IMG } from "../data/story";

type Tab = "data" | "material" | "energy";

const METALS = [
  { name: "镍", rate: 99.5, color: "#3fa08a" },
  { name: "钴", rate: 99.2, color: "#3a5f9e" },
  { name: "锰", rate: 99.1, color: "#8a7ab8" },
  { name: "锂", rate: 96.3, color: "#7a94a8" },
];

export default function Ch08() {
  const [tab, setTab] = useState<Tab>("data");
  const [lit, setLit] = useState(false);

  return (
    <div className="relative h-full w-full">
      <SceneImage
        src={tab === "data" ? IMG("scene15") : tab === "material" ? IMG("scene14") : IMG("scene16")}
        alt={
          tab === "data"
            ? "屏幕上的回收率数据与电池级原料"
            : tab === "material"
              ? "再生原料与矿石原料并排对比"
              : "火法冶炼与湿法冶金的能耗对比"
        }
        className="absolute inset-0"
      />

      {/* tabs */}
      <div className="absolute left-1/2 top-[6%] z-20 flex -translate-x-1/2 gap-2">
        {(
          [
            ["data", "回收数据"],
            ["material", "原料对比"],
            ["energy", "能耗对比"],
          ] as [Tab, string][]
        ).map(([k, label]) => (
          <button
            key={k}
            type="button"
            onClick={() => setTab(k)}
            className={`min-h-[40px] cursor-pointer px-4 text-sm tracking-widest transition-colors ${
              tab === k
                ? "bg-marine text-gold"
                : "bg-paper/85 text-marine hover:bg-paper"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "data" && (
        <div className="absolute bottom-[6%] left-1/2 z-20 w-[92%] max-w-lg -translate-x-1/2">
          {!lit ? (
            <div className="text-center">
              <GoldButton onClick={() => setLit(true)}>点亮数据</GoldButton>
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-2">
              {METALS.map((m, i) => (
                <motion.div
                  key={m.name}
                  initial={{ opacity: 0, y: 16, scale: 0.9 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ delay: i * 0.18, duration: 0.35 }}
                  className="bg-marine/90 p-3 text-center shadow-lg"
                  style={{ borderTop: `3px solid ${m.color}` }}
                >
                  <p className="text-xs tracking-widest text-[#f4ecd8]/80">{m.name}回收率</p>
                  <p className="font-display text-2xl text-gold">
                    <CountUp to={m.rate} decimals={1} start suffix="%" duration={1.4 + i * 0.2} />
                  </p>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === "material" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute bottom-[6%] left-1/2 z-20 w-[90%] max-w-md -translate-x-1/2 bg-marine/90 p-4 text-center shadow-lg"
        >
          <p className="text-sm leading-relaxed text-[#f4ecd8]">
            左边是从我体内提取的<span className="text-gold">电池级原料</span>，右边是从矿山开采的原矿——
            纯度、色泽，几乎一模一样。
          </p>
        </motion.div>
      )}

      {tab === "energy" && (
        <div className="absolute bottom-[6%] left-1/2 z-20 w-[92%] max-w-md -translate-x-1/2 space-y-2 bg-paper/90 p-4 shadow-lg">
          {[
            { label: "能耗", from: 100, to: 45, unit: "" },
            { label: "碳排放", from: 100, to: 42, unit: "" },
          ].map((b, i) => (
            <div key={b.label}>
              <div className="mb-1 flex justify-between text-xs text-ink">
                <span>{b.label}（湿法 vs 火法）</span>
                <span className="font-semibold text-leaf">降低 50%+</span>
              </div>
              <div className="flex h-3 w-full gap-1">
                <div className="h-full rounded-sm bg-[#a4453a]/70" style={{ width: "100%" }} title="火法冶炼" />
                <motion.div
                  className="h-full rounded-sm bg-leaf"
                  initial={{ width: "100%" }}
                  animate={{ width: `${b.to}%` }}
                  transition={{ delay: 0.2 + i * 0.2, duration: 1, ease: "easeOut" }}
                  title="湿法冶金"
                />
              </div>
            </div>
          ))}
          <p className="pt-1 text-center text-xs text-inksoft">红：传统火法 · 绿：绿色湿法</p>
        </div>
      )}
    </div>
  );
}
