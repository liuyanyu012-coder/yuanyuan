import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SceneImage, GoldButton } from "../components/bits";
import { IMG } from "../data/story";

const STEPS = [
  { id: "coat", name: "涂布", desc: "正极材料均匀涂上铝箔，像画家铺开颜料。" },
  { id: "wind", name: "卷绕", desc: "正负极片与隔膜卷成圆柱，一圈一圈，紧密有序。" },
  { id: "fill", name: "注液", desc: "电解液缓缓渗透，像春雨润物。" },
  { id: "form", name: "化成", desc: "首次充放电，电压曲线缓缓上升。" },
];

export default function Ch09() {
  const [step, setStep] = useState(0);
  const [reborn, setReborn] = useState(false);
  const [started, setStarted] = useState(false);
  const done = step === STEPS.length;

  return (
    <div className="relative h-full w-full">
      <SceneImage
        src={reborn ? IMG("scene18") : IMG("scene13")}
        alt={reborn ? "新电池装入新车，电量 100%" : "电池生产线：涂布、卷绕设备"}
        className="absolute inset-0"
      />

      {!reborn && (
        <>
          <AnimatePresence mode="wait">
            {step > 0 && (
              <motion.div
                key={STEPS[step - 1].id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="absolute left-1/2 top-[8%] z-20 w-[86%] max-w-sm -translate-x-1/2 bg-marine/90 p-3 text-center shadow-lg"
              >
                <p className="font-display text-lg text-gold">{STEPS[step - 1].name}</p>
                <p className="mt-1 text-sm text-[#f4ecd8]/90">{STEPS[step - 1].desc}</p>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="absolute bottom-[5%] left-1/2 z-20 flex -translate-x-1/2 flex-col items-center gap-3">
            <div className="flex items-center gap-2">
              {STEPS.map((s, i) => (
                <span
                  key={s.id}
                  className="rounded-full px-3 py-1 text-xs tracking-widest transition-all"
                  style={{
                    background: i < step ? "var(--teal)" : "rgba(255,255,255,.55)",
                    color: i < step ? "#fff" : "var(--ink-soft)",
                  }}
                >
                  {s.name}
                </span>
              ))}
            </div>
            {!done ? (
              <GoldButton onClick={() => setStep((s) => s + 1)}>
                {step === 0 ? "开始生产" : `下一道工序 · ${STEPS[step].name}`}
              </GoldButton>
            ) : (
              <GoldButton onClick={() => setReborn(true)}>见证新电池诞生</GoldButton>
            )}
          </div>
        </>
      )}

      {reborn && (
        <div className="absolute bottom-[6%] left-1/2 z-20 -translate-x-1/2 text-center">
          {!started ? (
            <GoldButton onClick={() => setStarted(true)}>启动车辆</GoldButton>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-marine px-8 py-4 shadow-xl"
            >
              <div className="mx-auto mb-2 h-2 w-40 overflow-hidden rounded-full bg-white/20">
                <motion.div
                  className="h-full rounded-full bg-[#7de3c0]"
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 1.6, ease: "easeOut" }}
                />
              </div>
              <p className="font-display text-3xl text-[#f4ecd8]">100%</p>
              <p className="mt-1 text-sm tracking-[0.3em] text-[#7de3c0]">我重生了</p>
            </motion.div>
          )}
        </div>
      )}
    </div>
  );
}
