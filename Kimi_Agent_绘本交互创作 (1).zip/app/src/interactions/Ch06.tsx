import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SceneImage, Hotspot } from "../components/bits";
import { IMG } from "../data/story";

const SCREWS = [
  { id: 1, x: "30%", y: "46%" },
  { id: 2, x: "42%", y: "40%" },
  { id: 3, x: "55%", y: "44%" },
  { id: 4, x: "63%", y: "52%" },
  { id: 5, x: "47%", y: "58%" },
  { id: 6, x: "35%", y: "62%" },
];

export default function Ch06() {
  const [removed, setRemoved] = useState<number[]>([]);
  const done = removed.length === SCREWS.length;
  const [laser, setLaser] = useState(false);

  const remove = (id: number) => {
    setRemoved((r) => (r.includes(id) ? r : [...r, id]));
    if (removed.length + 1 === SCREWS.length) {
      window.setTimeout(() => setLaser(true), 500);
    }
  };

  return (
    <div className="relative h-full w-full">
      <SceneImage src={IMG("scene23")} alt="机械臂精准拆解电池，激光切开密封胶" className="absolute inset-0" />

      {!done &&
        SCREWS.map((s) => (
          <Hotspot
            key={s.id}
            x={s.x}
            y={s.y}
            label={`拧下第 ${s.id} 颗螺丝`}
            done={removed.includes(s.id)}
            size={30}
            onClick={() => remove(s.id)}
          />
        ))}

      {/* laser seam */}
      <AnimatePresence>
        {laser && (
          <motion.svg
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
            className="pointer-events-none absolute inset-0 z-20 h-full w-full"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <motion.path
              d="M 26 50 L 40 46 L 58 47 L 70 54"
              fill="none"
              stroke="#6fd3e0"
              strokeWidth="0.7"
              strokeDasharray="4 2"
              initial={{ strokeDashoffset: 200, strokeDasharray: "100" }}
              animate={{ strokeDashoffset: 0 }}
              transition={{ duration: 1.6, ease: "easeInOut" }}
              style={{ filter: "drop-shadow(0 0 4px #6fd3e0)" }}
            />
          </motion.svg>
        )}
      </AnimatePresence>

      <div className="absolute bottom-[6%] left-1/2 z-30 -translate-x-1/2">
        {!done ? (
          <div className="bg-paper/90 px-5 py-2 text-sm text-marine shadow">
            扭矩恰到好处 · 已拧下 <span className="font-display text-lg text-golddeep">{removed.length}</span> / {SCREWS.length} 颗螺丝
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-marine px-6 py-3 text-center shadow-xl"
          >
            <p className="text-xs tracking-[0.3em] text-[#6fd3e0]">激光解胶完成</p>
            <p className="font-display text-xl text-[#f4ecd8]">电芯完好无损 · 无火花 · 无粉尘</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
