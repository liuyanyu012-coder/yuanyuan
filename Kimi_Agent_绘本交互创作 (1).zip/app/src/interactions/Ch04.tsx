import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SceneImage, GoldButton } from "../components/bits";
import { IMG } from "../data/story";

type Side = null | "left" | "right";

const COPY = {
  left: {
    tag: "小作坊的命运",
    text: "铁锤砸开外壳，电解液喷溅，废酸顺着沟渠排入河流。河水变黑，天空灰蒙蒙的。",
    tone: "var(--danger)",
  },
  right: {
    tag: "正规回收的命运",
    text: "明亮车间里，3D 相机扫描、机械臂精准操作，全程无火花、无噪音、无粉尘。",
    tone: "var(--teal)",
  },
};

export default function Ch04() {
  const [scene, setScene] = useState<"scene07" | "scene08">("scene07");
  const [side, setSide] = useState<Side>(null);
  const [seen, setSeen] = useState<Side[]>([]);

  const pick = (s: Exclude<Side, null>) => {
    setSide(s);
    setSeen((v) => (v.includes(s) ? v : [...v, s]));
  };

  const pan =
    side === "left"
      ? { x: "25%", y: "50%", scale: 1.6 }
      : side === "right"
        ? { x: "75%", y: "50%", scale: 1.6 }
        : undefined;

  return (
    <div className="relative h-full w-full">
      <SceneImage
        src={IMG(scene)}
        alt="小作坊与正规回收的命运分屏"
        className="absolute inset-0"
        pan={pan}
      />

      {/* half click zones */}
      <button
        type="button"
        aria-label="查看小作坊的命运"
        onClick={() => pick("left")}
        className="absolute inset-y-0 left-0 z-10 w-1/2 cursor-pointer"
      />
      <button
        type="button"
        aria-label="查看正规回收的命运"
        onClick={() => pick("right")}
        className="absolute inset-y-0 right-0 z-10 w-1/2 cursor-pointer"
      />

      {/* side labels */}
      {!side && (
        <>
          <span className="absolute left-[8%] top-[10%] z-20 bg-black/45 px-3 py-1 text-sm tracking-widest text-[#e8ddd0]">
            ← 小作坊
          </span>
          <span className="absolute right-[8%] top-[10%] z-20 bg-marine/70 px-3 py-1 text-sm tracking-widest text-[#f4ecd8]">
            正规回收 →
          </span>
        </>
      )}

      <AnimatePresence>
        {side && (
          <motion.div
            key={side + scene}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="absolute bottom-[14%] left-1/2 z-30 w-[90%] max-w-lg -translate-x-1/2 bg-marine/95 p-4 shadow-lg"
            style={{ borderLeft: `3px solid ${COPY[side].tone}` }}
          >
            <p className="text-xs font-semibold tracking-[0.28em]" style={{ color: COPY[side].tone === "var(--danger)" ? "#e0a196" : "#8fd0da" }}>
              {COPY[side].tag}
            </p>
            <p className="mt-1 text-sm leading-relaxed text-[#f4ecd8]">{COPY[side].text}</p>
            <button
              type="button"
              onClick={() => setSide(null)}
              className="mt-3 min-h-[36px] cursor-pointer border border-[#f4ecd8]/40 px-3 text-xs tracking-widest text-[#f4ecd8] transition-colors hover:bg-white/10"
            >
              看全景
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="absolute bottom-[4%] left-1/2 z-20 flex -translate-x-1/2 items-center gap-3">
        <GoldButton
          variant="outline"
          className="bg-paper/85"
          onClick={() => {
            setScene((s) => (s === "scene07" ? "scene08" : "scene07"));
            setSide(null);
          }}
        >
          切换另一幕
        </GoldButton>
        {seen.length === 2 && (
          <motion.span
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-teal px-4 py-2 text-sm font-semibold tracking-widest text-white"
          >
            两种命运 · 一条归途
          </motion.span>
        )}
      </div>
    </div>
  );
}
