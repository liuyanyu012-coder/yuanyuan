import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SceneImage, Hotspot, GoldButton } from "../components/bits";
import { IMG } from "../data/story";

const ATOMS = [
  { id: "li", name: "锂", color: "银白", desc: "最轻的金属，能量的精灵", x: "30%", y: "58%", hex: "#c8ccd4" },
  { id: "co", name: "钴", color: "幽蓝", desc: "深邃稳定，身价不菲", x: "56%", y: "42%", hex: "#3a6ea8" },
  { id: "ni", name: "镍", color: "青绿", desc: "让续航更持久", x: "72%", y: "66%", hex: "#3fa08a" },
  { id: "mn", name: "锰", color: "淡紫", desc: "安全的守护者", x: "44%", y: "76%", hex: "#8a7ab8" },
];

export default function Ch01() {
  const [micro, setMicro] = useState(false);
  const [found, setFound] = useState<string[]>([]);
  const [current, setCurrent] = useState<(typeof ATOMS)[0] | null>(null);

  return (
    <div className="relative h-full w-full">
      <SceneImage
        src={micro ? IMG("scene02") : IMG("scene01")}
        alt={micro ? "电池内部的微观世界，原子如星辰排列" : "无尘自动化工厂，机械臂舞动"}
        className="absolute inset-0"
      />

      {!micro && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="absolute bottom-[16%] left-1/2 z-20 -translate-x-1/2"
        >
          <GoldButton onClick={() => setMicro(true)}>穿越外壳 · 进入微观世界</GoldButton>
        </motion.div>
      )}

      {micro && (
        <>
          {ATOMS.map((a) => (
            <Hotspot
              key={a.id}
              x={a.x}
              y={a.y}
              label={`${a.name}原子`}
              color={a.hex}
              done={found.includes(a.id)}
              onClick={() => {
                setCurrent(a);
                setFound((f) => (f.includes(a.id) ? f : [...f, a.id]));
              }}
            />
          ))}

          <AnimatePresence>
            {current && (
              <motion.div
                key={current.id}
                initial={{ opacity: 0, y: 8, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0 }}
                className="absolute left-1/2 top-[8%] z-30 -translate-x-1/2 bg-marine/90 px-4 py-2 text-center shadow-md backdrop-blur-sm"
              >
                <span className="font-display text-lg text-gold">{current.name}</span>
                <span className="mx-2 text-[#f4ecd8]/60">·</span>
                <span className="text-sm text-[#f4ecd8]">{current.color}</span>
                <span className="mx-2 text-[#f4ecd8]/60">·</span>
                <span className="text-sm text-[#f4ecd8]/90">{current.desc}</span>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="absolute bottom-[16%] left-1/2 z-20 flex -translate-x-1/2 items-center gap-3">
            <GoldButton variant="outline" onClick={() => setMicro(false)} className="bg-paper/80">
              返回工厂
            </GoldButton>
            {found.length === ATOMS.length && (
              <motion.span
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-leaf px-4 py-2 text-sm font-semibold tracking-widest text-white"
              >
                城市矿山已点亮 · {found.length}/4
              </motion.span>
            )}
          </div>
        </>
      )}
    </div>
  );
}
