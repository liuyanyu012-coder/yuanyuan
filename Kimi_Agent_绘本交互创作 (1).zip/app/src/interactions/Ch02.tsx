import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SceneImage } from "../components/bits";
import { IMG } from "../data/story";

const STOPS = [
  { max: 33, src: "scene03", label: "第一年 · 清晨出发" },
  { max: 66, src: "scene04", label: "第三年 · 山海之间" },
  { max: 100, src: "scene05", label: "第五年 · 电量警告" },
];

export default function Ch02() {
  const [t, setT] = useState(0);
  const stop = STOPS.find((s) => t <= s.max) ?? STOPS[2];
  const capacity = Math.round(100 - t * 0.3);
  const year = Math.max(1, Math.ceil((t / 100) * 5));

  return (
    <div className="relative h-full w-full">
      <SceneImage src={IMG(stop.src)} alt="五年时光的蒙太奇" className="absolute inset-0" />

      {/* capacity gauge */}
      <div className="absolute right-[4%] top-[8%] z-20 w-40 bg-paper/85 p-3 shadow-md backdrop-blur-sm md:w-48">
        <div className="mini-title mb-2">剩余容量</div>
        <div className="flex items-end gap-1">
          <span
            className="font-display text-3xl leading-none"
            style={{ color: capacity > 80 ? "var(--leaf)" : capacity > 70 ? "var(--gold-deep)" : "var(--danger)" }}
          >
            {capacity}
          </span>
          <span className="text-sm text-inksoft">%</span>
        </div>
        <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-[#d9cfb4]">
          <motion.div
            className="h-full rounded-full"
            animate={{
              width: `${capacity}%`,
              backgroundColor: capacity > 80 ? "#4c8a5a" : capacity > 70 ? "#cea84e" : "#a4453a",
            }}
            transition={{ duration: 0.3 }}
          />
        </div>
        <AnimatePresence>
          {capacity <= 70 && (
            <motion.p
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-2 text-xs font-semibold text-danger"
            >
              ⚠ 请检查动力电池
            </motion.p>
          )}
        </AnimatePresence>
      </div>

      {/* time slider */}
      <div className="absolute bottom-[6%] left-1/2 z-20 w-[86%] max-w-xl -translate-x-1/2 bg-paper/85 px-5 py-4 shadow-md backdrop-blur-sm">
        <div className="mb-2 flex items-center justify-between text-sm">
          <span className="font-display text-base text-marine">{stop.label}</span>
          <span className="text-inksoft">第 {year} 年</span>
        </div>
        <input
          type="range"
          min={0}
          max={100}
          value={t}
          aria-label="拖动时间，从第一年到第五年"
          onChange={(e) => setT(Number(e.target.value))}
          className="book-range w-full"
          style={{ ["--fill" as string]: `${t}%` }}
        />
        <div className="mt-1 flex justify-between text-[11px] tracking-widest text-inksoft">
          <span>第 1 年</span>
          <span>第 3 年</span>
          <span>第 5 年</span>
        </div>
      </div>
    </div>
  );
}
