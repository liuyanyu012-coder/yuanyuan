import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { SceneImage, GoldButton } from "../components/bits";
import { IMG } from "../data/story";

export default function Ch10() {
  const [cycles, setCycles] = useState(0);
  const [auto, setAuto] = useState(false);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (auto) {
      timer.current = window.setInterval(() => {
        setCycles((c) => {
          if (c >= 100) {
            setAuto(false);
            return c;
          }
          return c + 1;
        });
      }, 120);
    }
    return () => {
      if (timer.current) window.clearInterval(timer.current);
    };
  }, [auto]);

  return (
    <div className="relative h-full w-full">
      <SceneImage src={IMG("scene17")} alt="电池回收循环之环" className="absolute inset-0" />

      {/* spinning ring overlay */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2">
        <div
          className="spin-slow h-[46vmin] w-[46vmin] rounded-full border-2 border-dashed border-gold/70"
          style={{ animationDuration: cycles > 30 ? "6s" : cycles > 0 ? "12s" : "18s" }}
        />
      </div>

      {/* cycle counter */}
      <div className="absolute left-1/2 top-[10%] z-20 -translate-x-1/2 bg-marine/90 px-6 py-3 text-center shadow-lg">
        <p className="text-xs tracking-[0.3em] text-[#f4ecd8]/70">循环次数</p>
        <motion.p key={cycles} className="font-display text-4xl text-gold">
          {cycles}
        </motion.p>
      </div>

      <div className="absolute bottom-[5%] left-1/2 z-20 flex -translate-x-1/2 items-center gap-3">
        <GoldButton onClick={() => setCycles((c) => c + 1)}>转动一圈</GoldButton>
        <GoldButton variant="outline" className="bg-paper/85" onClick={() => setAuto((a) => !a)}>
          {auto ? "停下" : "自动循环"}
        </GoldButton>
      </div>

      {cycles >= 100 && (
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute bottom-[16%] left-1/2 z-20 w-[88%] max-w-md -translate-x-1/2 bg-leaf px-4 py-2 text-center text-sm text-white shadow-lg"
        >
          钴、镍、锂可以循环几十次甚至上百次——这是一座永不枯竭的城市矿山。
        </motion.p>
      )}
    </div>
  );
}
