import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SceneImage, Hotspot, GoldButton } from "../components/bits";
import { IMG } from "../data/story";

type Phase = "choice" | "qr" | "scanning" | "card";

export default function Ch03() {
  const [phase, setPhase] = useState<Phase>("choice");
  const [warned, setWarned] = useState(false);

  const scan = () => {
    setPhase("scanning");
    window.setTimeout(() => setPhase("card"), 1600);
  };

  return (
    <div className="relative h-full w-full">
      <SceneImage
        src={phase === "choice" ? IMG("scene06") : IMG("scene09")}
        alt={phase === "choice" ? "4S 店售后区，经理递来政策文件" : "在回收协议上签字，电池贴上二维码"}
        className="absolute inset-0"
      />

      {phase === "choice" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="absolute bottom-[6%] left-1/2 z-20 flex w-[92%] max-w-2xl -translate-x-1/2 flex-col items-stretch gap-3 md:flex-row"
        >
          <motion.button
            type="button"
            onClick={() => setWarned(true)}
            animate={warned ? { x: [0, -8, 8, -6, 6, 0] } : {}}
            transition={{ duration: 0.45 }}
            className="min-h-[56px] flex-1 cursor-pointer border border-[#7a5a4a]/50 bg-[#3a3230]/90 px-4 py-3 text-left text-sm text-[#e8ddd0] shadow-md transition-colors hover:bg-[#4a403c]"
          >
            <span className="block font-semibold">路边小广告</span>
            <span className="text-xs opacity-80">“高价回收动力电池，现金结算，上门拆解”</span>
          </motion.button>
          <button
            type="button"
            onClick={() => setPhase("qr")}
            className="min-h-[56px] flex-1 cursor-pointer border border-gold bg-marine/95 px-4 py-3 text-left text-sm text-[#f4ecd8] shadow-md transition-colors hover:bg-marinesoft"
          >
            <span className="block font-semibold text-gold">听售后经理的</span>
            <span className="text-xs opacity-85">“车电一体”处理，签正规回收协议</span>
          </button>
        </motion.div>
      )}

      <AnimatePresence>
        {warned && phase === "choice" && (
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="absolute bottom-[22%] left-1/2 z-30 w-[88%] max-w-md -translate-x-1/2 bg-danger/95 px-4 py-2 text-center text-sm text-white shadow-lg"
          >
            阴暗的小作坊、铁锤与酸液……那不是我的归途。再想想？
          </motion.p>
        )}
      </AnimatePresence>

      {phase === "qr" && (
        <Hotspot x="50%" y="52%" label="贴上数字身份证" onClick={scan} size={46} />
      )}
      {phase === "qr" && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="absolute bottom-[8%] left-1/2 z-20 -translate-x-1/2 bg-paper/90 px-4 py-2 text-sm text-marine shadow"
        >
          点击电池上的二维码，为我贴上“数字身份证”
        </motion.div>
      )}

      {phase === "scanning" && (
        <div className="absolute inset-0 z-30">
          <SceneImage src={IMG("scene09")} alt="扫码中" className="absolute inset-0" />
          <div
            className="scan-line absolute top-[20%] h-[55%] w-[3px]"
            style={{ background: "linear-gradient(to bottom, transparent, #6fd3e0, transparent)", boxShadow: "0 0 18px 4px rgba(111,211,224,.8)" }}
          />
          <p className="absolute bottom-[10%] left-1/2 -translate-x-1/2 bg-marine/90 px-4 py-2 text-sm tracking-[0.3em] text-[#6fd3e0]">
            “嘀”—— 数据汇入全国溯源平台
          </p>
        </div>
      )}

      <AnimatePresence>
        {phase === "card" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-40 flex items-center justify-center bg-marine/60 p-4 backdrop-blur-sm"
            onClick={() => setPhase("qr")}
          >
            <motion.div
              initial={{ scale: 0.92, y: 16 }}
              animate={{ scale: 1, y: 0 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              className="w-full max-w-sm bg-paper p-6 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
              role="dialog"
              aria-label="电池数字身份证"
            >
              <div className="mini-title mb-3">全国动力电池溯源平台</div>
              <h3 className="font-display text-2xl text-marine">数字身份证</h3>
              <dl className="mt-4 space-y-2 text-sm">
                {[
                  ["编号", "LB-2026-070431"],
                  ["产地", "无尘自动化工厂"],
                  ["体内材料", "锂 · 钴 · 镍 · 锰"],
                  ["使用年限", "5 年（剩余容量 70%）"],
                  ["流向", "智能拆解中心 → 湿法冶金车间"],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-4 border-b border-dashed border-[#d9cfb4] pb-1">
                    <dt className="text-inksoft">{k}</dt>
                    <dd className="text-right font-medium text-marine">{v}</dd>
                  </div>
                ))}
              </dl>
              <div className="mt-5 text-center">
                <GoldButton onClick={() => setPhase("qr")}>收起证件</GoldButton>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
