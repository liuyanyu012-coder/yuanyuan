import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SceneImage, Hotspot, GoldButton, CountUp } from "../components/bits";
import { IMG } from "../data/story";

const PARTS = [
  { id: "shell", label: "外壳厚度", x: "33%", y: "52%" },
  { id: "screw", label: "螺丝位置", x: "44%", y: "44%" },
  { id: "module", label: "内部模组排列", x: "52%", y: "58%" },
  { id: "wire", label: "线束走向", x: "41%", y: "66%" },
];

type Phase = "idle" | "scanning" | "done";

export default function Ch05() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [found, setFound] = useState<string[]>([]);

  const startScan = () => {
    setPhase("scanning");
    window.setTimeout(() => setPhase("done"), 2500);
  };

  return (
    <div className="relative h-full w-full">
      <SceneImage src={IMG("scene10")} alt="电池被送入扫描舱，3D 相机开始工作" className="absolute inset-0" />

      {phase === "scanning" && (
        <>
          <div
            className="scan-line absolute top-[18%] z-20 h-[60%] w-[3px]"
            style={{ background: "linear-gradient(to bottom, transparent, #7de3c0, transparent)", boxShadow: "0 0 20px 5px rgba(125,227,192,.75)" }}
          />
          <p className="absolute left-1/2 top-[10%] z-20 -translate-x-1/2 bg-marine/85 px-4 py-2 text-sm tracking-[0.3em] text-[#7de3c0]">
            3D 视觉扫描中……
          </p>
        </>
      )}

      {phase === "done" &&
        PARTS.map((p) => (
          <Hotspot
            key={p.id}
            x={p.x}
            y={p.y}
            label={p.label}
            color="#2e7d8a"
            done={found.includes(p.id)}
            onClick={() => setFound((f) => (f.includes(p.id) ? f : [...f, p.id]))}
          />
        ))}

      <AnimatePresence>
        {phase === "done" && found.length > 0 && found.length < PARTS.length && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute left-1/2 top-[8%] z-30 -translate-x-1/2 bg-paper/90 px-4 py-2 text-sm text-marine shadow"
          >
            已标注 {found.length}/4 处结构：{PARTS.filter((p) => found.includes(p.id)).map((p) => p.label).join("、")}
          </motion.p>
        )}
      </AnimatePresence>

      <div className="absolute bottom-[6%] left-1/2 z-20 -translate-x-1/2">
        {phase === "idle" && <GoldButton onClick={startScan}>开始扫描</GoldButton>}
        {phase === "done" && found.length === PARTS.length && (
          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-marine px-6 py-3 text-center shadow-xl"
          >
            <p className="text-xs tracking-[0.3em] text-[#7de3c0]">结构识别完成</p>
            <p className="font-display text-3xl text-[#f4ecd8]">
              耗时 <CountUp to={2.8} decimals={1} start duration={1.2} /> 秒
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
