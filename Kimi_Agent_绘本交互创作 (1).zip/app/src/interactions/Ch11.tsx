import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SceneImage, Hotspot, GoldButton } from "../components/bits";
import { IMG } from "../data/story";

const STOPS = [
  { id: "phone", shout: "等等——", x: "17%", y: "22%", tip: "旧手机别进抽屉，它体内也有一座矿山。" },
  { id: "scooter", shout: "别急——", x: "50%", y: "22%", tip: "电动车电池不能低价卖给路边小贩。" },
  { id: "powerbank", shout: "住手——", x: "83%", y: "22%", tip: "充电宝进垃圾桶？绝对不行。" },
];

const CERT_NO = `CM-2026-${Math.floor(10000 + Math.random() * 89999)}`;

export default function Ch11() {
  const [phase, setPhase] = useState<"stop" | "drop" | "cert">("stop");
  const [saved, setSaved] = useState<string[]>([]);
  const [tip, setTip] = useState<string | null>(null);
  const [inBin, setInBin] = useState(false);
  const dropRef = useRef<HTMLDivElement>(null);

  const allSaved = saved.length === STOPS.length;

  const checkDrop = (x: number, y: number) => {
    const r = dropRef.current?.getBoundingClientRect();
    if (r && x > r.left - 30 && x < r.right + 30 && y > r.top - 30 && y < r.bottom + 30) {
      setInBin(true);
      window.setTimeout(() => setPhase("cert"), 900);
    }
  };

  return (
    <div className="relative h-full w-full">
      {phase !== "cert" && (
        <SceneImage
          src={phase === "stop" ? IMG("scene19") : IMG("scene20")}
          alt={phase === "stop" ? "三个危险的瞬间：旧手机、旧电池、旧充电宝" : "把旧电池投入回收箱"}
          className="absolute inset-0"
        />
      )}

      {phase === "stop" && (
        <>
          {STOPS.map((s) => (
            <div key={s.id}>
              <Hotspot
                x={s.x}
                y={s.y}
                label={s.shout}
                color="var(--danger)"
                done={saved.includes(s.id)}
                size={40}
                onClick={() => {
                  setTip(s.tip);
                  setSaved((v) => (v.includes(s.id) ? v : [...v, s.id]));
                }}
              />
              {!saved.includes(s.id) && (
                <span
                  className="pointer-events-none absolute z-20 -translate-x-1/2 bg-danger px-2 py-0.5 text-xs font-bold tracking-widest text-white"
                  style={{ left: s.x, top: `calc(${s.y} + 30px)` }}
                >
                  {s.shout}
                </span>
              )}
            </div>
          ))}

          <AnimatePresence>
            {tip && !allSaved && (
              <motion.p
                key={tip}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="absolute bottom-[14%] left-1/2 z-30 w-[88%] max-w-md -translate-x-1/2 bg-marine/90 px-4 py-2 text-center text-sm text-[#f4ecd8] shadow-lg"
              >
                {tip}
              </motion.p>
            )}
          </AnimatePresence>

          {allSaved && (
            <motion.div
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute bottom-[6%] left-1/2 z-30 -translate-x-1/2"
            >
              <GoldButton onClick={() => setPhase("drop")}>前往正规回收点</GoldButton>
            </motion.div>
          )}
        </>
      )}

      {phase === "drop" && (
        <>
          {/* drop zone over the recycling slot */}
          <div
            ref={dropRef}
            className={`absolute z-10 flex items-center justify-center rounded-lg border-2 border-dashed transition-colors ${
              inBin ? "border-leaf bg-leaf/15" : "border-gold bg-gold/10"
            }`}
            style={{ left: "39%", top: "55%", width: "23%", height: "20%" }}
          >
            <span className="text-xs tracking-widest text-marine">{inBin ? "嘀——感谢" : "投到这里"}</span>
          </div>

          {!inBin && (
            <motion.img
              src="images/battery.png"
              alt="旧电池，拖动我到回收箱"
              drag
              dragMomentum={false}
              onDragEnd={(_, info) => checkDrop(info.point.x, info.point.y)}
              onDoubleClick={() => {
                setInBin(true);
                window.setTimeout(() => setPhase("cert"), 900);
              }}
              whileDrag={{ scale: 1.08 }}
              whileTap={{ scale: 1.05 }}
              className="absolute z-30 w-24 cursor-grab active:cursor-grabbing md:w-28"
              style={{ left: "8%", top: "30%" }}
            />
          )}
          {!inBin && (
            <div className="absolute right-[4%] top-[6%] z-40 flex max-w-[170px] flex-col gap-2 bg-paper/90 px-3 py-2 shadow">
              <p className="text-xs leading-relaxed text-marine">拖动我（或双击我），投进回收箱</p>
              <button
                type="button"
                onClick={() => {
                  setInBin(true);
                  window.setTimeout(() => setPhase("cert"), 900);
                }}
                className="min-h-[36px] cursor-pointer bg-marine px-3 text-xs tracking-widest text-gold transition-colors hover:bg-marinesoft"
              >
                直接投入
              </button>
            </div>
          )}

          {inBin && (
            <motion.div
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="absolute left-1/2 top-[30%] z-30 -translate-x-1/2 bg-leaf px-6 py-3 text-center shadow-xl"
            >
              <p className="font-display text-xl text-white">“嘀”——</p>
              <p className="text-sm tracking-[0.25em] text-white/90">感谢您，城市矿工</p>
            </motion.div>
          )}
        </>
      )}

      <AnimatePresence>
        {phase === "cert" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 z-40 flex items-center justify-center bg-marine/70 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
              className="w-full max-w-sm bg-paper p-6 text-center shadow-2xl"
              role="dialog"
              aria-label="城市矿工证书"
            >
              <img src="images/battery.png" alt="小电池" className="floaty mx-auto w-20" />
              <div className="mini-title mt-2 justify-center">正规回收 · 电子凭证</div>
              <h3 className="font-display mt-2 text-3xl text-marine">城市矿工证书</h3>
              <div className="mx-auto mt-4 space-y-1 border-y border-dashed border-[#d9cfb4] py-3 text-sm text-ink">
                <p>编号：{CERT_NO}</p>
                <p>日期：2026 年 10 月 17 日</p>
              </div>
              <p className="font-narr mt-4 text-base leading-relaxed text-marine">
                你的一个动作，就是我的新起点。
              </p>
              <div className="mt-5">
                <GoldButton onClick={() => setPhase("stop")}>再玩一次</GoldButton>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
